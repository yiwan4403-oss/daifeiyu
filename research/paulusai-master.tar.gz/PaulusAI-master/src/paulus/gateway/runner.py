"""GatewayRunner: routes messages between platform adapters and the agent."""
from __future__ import annotations

import asyncio
import concurrent.futures
import itertools
import time

from .. import billing, config, grants, security
from .base import SILENCE_TOKENS, AdapterState, BasePlatformAdapter, SessionSource
from .presence import PresenceStore
from .session_store import SessionStore

_instance: GatewayRunner | None = None

# Leaves room for the prompt's framing and an auto-review concern within
# Telegram's 4096-char message limit.
_APPROVAL_DETAIL_LIMIT = 3000


def get_runner() -> GatewayRunner | None:
    return _instance


def _approval_prompt(tool_name: str, tool_input, concern: str | None = None,
                     origin: str | None = None, grantable: bool = False) -> str:
    """A concise, human-readable description of the action awaiting approval."""
    if isinstance(tool_input, dict):
        if tool_name == "run_command":
            detail = tool_input.get("command", "")
        elif tool_name == "write_local_file":
            detail = f"write to {tool_input.get('path', '?')}"
        elif tool_name == "send_message":
            body = str(tool_input.get("body", ""))
            preview = body if len(body) <= 200 else body[:200] + "…"
            detail = f"to {tool_input.get('to', '?')}: {preview}"
        elif tool_name == "send_email_agentmail":
            body = str(tool_input.get("body", ""))
            preview = body if len(body) <= 200 else body[:200] + "…"
            detail = (f"email to {tool_input.get('to', '?')}, subject "
                      f"'{tool_input.get('subject', '')}': {preview}")
        elif tool_name == "send_document":
            dest = tool_input.get("to") or "the current chat"
            detail = f"file '{tool_input.get('filename', '?')}' to {dest}"
        else:
            detail = str(tool_input)
    else:
        detail = str(tool_input)
    # Platforms cap message length (Telegram: 4096). A prompt over the cap fails
    # to send, which denies the action outright — e.g. a heredoc that writes a
    # whole file. Show the head and say how much is hidden instead.
    if len(detail) > _APPROVAL_DETAIL_LIMIT:
        hidden = len(detail) - _APPROVAL_DETAIL_LIMIT
        detail = f"{detail[:_APPROVAL_DETAIL_LIMIT]}… [+{hidden} more chars not shown]"
    source = f"From: {origin}\n" if origin else ""
    flagged = f"Auto-review flagged: {concern}\n" if concern else ""
    scope = ""
    if grantable:
        scope = ("\n“Allow for this task” also allows "
                 f"{grants.describe(grants.keys(tool_name, tool_input))} "
                 "until this task ends.")
    return (
        "⚠️ Approval needed for a high-impact action.\n"
        f"{source}"
        f"Action: {tool_name}\n"
        f"Details: {detail}\n"
        f"{flagged}\n"
        f"Approve this single action?{scope}"
    )


class GatewayRunner:
    """
    Manages platform adapters, routes inbound messages to the agent, and
    dispatches outbound messages from the send_message tool.
    """
    def __init__(self) -> None:
        global _instance
        self._adapters: dict[str, BasePlatformAdapter] = {}
        self._sessions = SessionStore()
        self._presence = PresenceStore(config.PRESENCE_FILE)
        # Serialize conversation turns, so each one sees the last one's reply.
        # Background tasks (tasks.py) run beside them, outside this lock; the
        # memory stores lock themselves.
        self._agent_lock = asyncio.Lock()
        self._idle_task: asyncio.Task | None = None
        # The gateway event loop, captured once it is running, so the agent's
        # worker thread can marshal interactive-approval prompts back onto it.
        self._loop: asyncio.AbstractEventLoop | None = None
        # Pending high-impact approvals awaiting a user's Approve/Deny, keyed by
        # a short id carried in the prompt's callback.
        self._pending_approvals: dict[str, concurrent.futures.Future] = {}
        # Prompts are requested from several threads at once (subagents,
        # background tasks); next() on a count is atomic, += is not.
        self._approval_seq = itertools.count(1)
        _instance = self
        from .. import tasks
        tasks.set_notifier(self.notify_user)

    def register(self, name: str, adapter: BasePlatformAdapter) -> None:
        self._adapters[name] = adapter

    def has_adapters(self) -> bool:
        return bool(self._adapters)

    def _is_user_authorized(self, source: SessionSource, allowed: set[str]) -> bool:
        return not allowed or str(source.user_id) in allowed

    async def handle_inbound(self, source: SessionSource, text: str,
                             images: list | None = None,
                             documents: list | None = None) -> None:
        """Called by adapters when a message arrives from a platform user.

        ``images`` (optional) is a list of ``{"media_type", "data"}`` dicts
        (base64) attached to this turn — used by adapters that accept photos.
        ``documents`` (optional) is a list of ``{"filename", "content"}`` text
        documents — folded into the turn and saved to the user's workspace."""
        session = self._sessions.get_or_create(source.key())
        session.touch()
        self._presence.touch(source)   # per-user idle clock + reachability

        tagged = f"[via {source.platform}] {text}"

        adapter = self._adapters.get(source.platform)
        # Stream (live-edit the reply as it's generated) when the adapter opts
        # in; otherwise deliver the reply in one shot once it's complete.
        sink = None
        if (adapter and adapter.state == AdapterState.RUNNING
                and getattr(adapter, "supports_streaming", False)):
            sink = adapter.stream_sink(source, asyncio.get_running_loop())

        reply = None
        error: Exception | None = None
        async with self._agent_lock:
            from .. import agent as _agent
            loop = asyncio.get_running_loop()
            user_id = str(source.user_id)
            on_delta = sink.feed if sink else None
            on_break = sink.end_segment if sink else None
            try:
                reply = await loop.run_in_executor(
                    None,
                    lambda: _agent.respond(tagged, user_id=user_id, on_delta=on_delta,
                                           images=images, documents=documents,
                                           on_break=on_break),
                )
            except Exception as exc:        # model/tool failure mid-turn
                error = exc

        # The agent raised (e.g. a non-vision model rejecting an image). Drop any
        # streamed placeholder and tell the user, instead of dying silently.
        if error is not None:
            security.audit("gateway_agent_error", f"{source.key()}: {error}")
            if sink is not None:
                try:
                    await sink.discard()
                except Exception:
                    pass
            note = (
                "Sorry — I couldn't process that image. The model it was sent "
                "to may not be vision-capable; set DP_CORE_MODEL (or "
                "DP_ROUTER_MODEL) to one that supports images."
                if images else
                "Sorry — something went wrong handling that. Please try again."
            )
            if adapter and adapter.state == AdapterState.RUNNING:
                try:
                    await adapter.send(source, note)
                except Exception as exc:
                    security.audit("gateway_send_error", str(exc))
                    adapter._on_failure()
            return

        # A pay-gate block carries its top-up link inline (see billing.gate());
        # pull it back out so it can render as a real button rather than a
        # pasted URL. text == reply, unchanged, when no link is present.
        text, pay_url = billing.split_pay_link(reply)
        silent = any(token in text for token in SILENCE_TOKENS)

        if sink is not None:
            try:
                if silent:
                    await sink.discard()
                elif pay_url:
                    # Nothing was streamed for a pay-gate block (it short-circuits
                    # before the model runs), so there's no placeholder to finalize.
                    await sink.discard()
                    await adapter.send_with_link(source, text, billing.TOPUP_BUTTON_LABEL, pay_url)
                else:
                    await sink.finalize(reply)
                adapter._on_success()
            except Exception as exc:
                security.audit("gateway_send_error", str(exc))
                adapter._on_failure()
            return

        if silent:
            return
        if adapter and adapter.state == AdapterState.RUNNING:
            try:
                if pay_url:
                    await adapter.send_with_link(source, text, billing.TOPUP_BUTTON_LABEL, pay_url)
                else:
                    await adapter.send(source, text)
                adapter._on_success()
            except Exception as exc:
                security.audit("gateway_send_error", str(exc))
                adapter._on_failure()

    async def handle_command(self, source: SessionSource, command: str,
                             args: str = "") -> str:
        """Run an in-chat slash command and return the reply text. Mirrors the
        terminal CLI's /sleep, /mood, /memory, /skills, /bg, /tasks and
        /cancel, but scoped to the calling user (per-user episodic/semantic
        memory and tasks; skills and mood are global). Called by adapters that
        register command handlers."""
        from .. import affect, memory, skills, tasks
        user_id = str(source.user_id)

        if command == "bg":
            # Starting a task is quick (routing + a thread), but it reads and
            # writes memory, so it takes the same path as a turn.
            self._presence.touch(source)
            async with self._agent_lock:
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(
                    None, lambda: tasks.start_from_owner(args, user_id=user_id))
        if command == "tasks":
            return tasks.status(user_id)
        if command == "cancel":
            return tasks.cancel(user_id, args.strip())

        if command == "sleep":
            # Consolidation hits the model and writes memory, so it runs under
            # the agent lock (PaulusAI's memory modules aren't thread-safe) and
            # off the event loop, exactly like a normal turn.
            self._presence.touch(source)
            async with self._agent_lock:
                from .. import agent as _agent
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(
                    None, lambda: _agent.sleep(user_id=user_id)
                )
        if command == "mood":
            return f"mood: {affect.describe()}"
        if command == "memory":
            return memory.semantic_text(user_id)
        if command == "skills":
            return skills.describe()
        return f"Unknown command: /{command}"

    def notify_user(self, user_id, text: str) -> None:
        """Deliver *text* to *user_id*'s most recent chat. Called from a
        background task's thread when it finishes; blocks until sent."""
        source, error = self._resolve_destination("", user_id)
        if error is not None or self._loop is None:
            security.audit("notify_skip", f"{user_id}: {error or 'loop not running'}")
            return
        adapter = self._adapters[source.platform]
        # A task stopped for balance carries its top-up link (billing.metered).
        text, pay_url = billing.split_pay_link(text)
        send = (adapter.send_with_link(source, text, billing.TOPUP_BUTTON_LABEL, pay_url)
                if pay_url else adapter.send(source, text))
        try:
            asyncio.run_coroutine_threadsafe(send, self._loop).result(timeout=60)
            adapter._on_success()
        except Exception as exc:
            security.audit("notify_error", f"{user_id}: {exc}")
            adapter._on_failure()

    def _resolve_target(self, to: str) -> tuple[str | None, str, str | None]:
        """Resolve a 'to' spec into (platform_name, chat_id, error).
        'to' format: 'platform:chat_id' or bare 'chat_id' for the default adapter.
        ``error`` is a user-facing string when no live adapter can serve it."""
        parts = to.split(":", 1)
        if len(parts) == 2:
            platform_name, chat_id = parts
        else:
            platform_name = self._default_platform()
            chat_id = to
            if platform_name is None:
                return None, chat_id, f"[gateway] no active adapter to deliver to {to}."

        adapter = self._adapters.get(platform_name)
        if not adapter or adapter.state != AdapterState.RUNNING:
            return None, chat_id, f"[{platform_name}] adapter unavailable; nothing sent to {to}."
        return platform_name, chat_id, None

    def _schedule_send(self, coro) -> None:
        """Run an adapter send coroutine on the gateway loop, or synchronously
        when there is no running loop (terminal REPL mode)."""
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(coro)
        except RuntimeError:
            asyncio.run(coro)

    def dispatch_outbound(self, to: str, body: str) -> str:
        """
        Deliver an outbound message; called synchronously from tools.execute().
        'to' format: 'platform:chat_id' or bare 'chat_id' for the default adapter.
        """
        platform_name, chat_id, error = self._resolve_target(to)
        if error is not None:
            return error

        adapter = self._adapters[platform_name]
        source = SessionSource(platform=platform_name, chat_id=chat_id, user_id="agent")
        self._schedule_send(adapter.send(source, body))
        return f"Message dispatched to {to} via {platform_name}."

    def _resolve_destination(self, to: str, user_id) -> tuple[SessionSource | None, str | None]:
        """Resolve where an agent-initiated payload should go, returning
        (source, error). An explicit ``to`` ('platform:chat_id' or bare chat_id)
        wins; otherwise it falls back to the caller's most recent reachable
        conversation — preserving its thread — so the agent can answer in the
        current chat without knowing the chat id."""
        if to:
            platform_name, chat_id, error = self._resolve_target(to)
            if error is not None:
                return None, error
            return SessionSource(platform=platform_name, chat_id=chat_id, user_id="agent"), None

        presence = self._presence._users.get(str(user_id)) if user_id is not None else None
        if presence is None:
            return None, "[gateway] no destination given and no known chat for this user."
        src = presence.last_source
        adapter = self._adapters.get(src.platform)
        if not adapter or adapter.state != AdapterState.RUNNING:
            return None, f"[{src.platform}] adapter unavailable; nothing sent."
        return SessionSource(platform=src.platform, chat_id=src.chat_id,
                             user_id="agent", thread_id=src.thread_id), None

    def dispatch_document(self, to: str, filename: str, body: str, user_id=None) -> str:
        """Deliver an outbound text document as a file attachment; called
        synchronously from tools.execute(). ``to`` is optional: when empty, the
        document goes to the calling user's current chat (see
        ``_resolve_destination``). Falls back with a note if the target adapter
        can't send documents."""
        source, error = self._resolve_destination(to, user_id)
        if error is not None:
            return error

        adapter = self._adapters[source.platform]
        if not getattr(adapter, "supports_documents", False):
            return f"[{source.platform}] adapter can't send documents; {filename} not sent."

        self._schedule_send(adapter.send_document(source, filename, body))
        return f"Document '{filename}' dispatched to {source.platform}:{source.chat_id}."

    def _default_platform(self) -> str | None:
        for name, adapter in self._adapters.items():
            if adapter.state == AdapterState.RUNNING:
                return name
        return None

    # ------------------------------------------------------------------
    # Interactive approval of high-impact actions
    # ------------------------------------------------------------------

    def request_approval(self, user_id: str, tool_name: str, tool_input,
                         concern: str | None = None, origin: str | None = None,
                         grantable: bool = False) -> bool | str | None:
        """Ask a reachable user to approve a single high-impact action.

        Called synchronously from the agent's worker thread (the gate blocks
        there). Returns True (approved), security.GRANT (approved, and similar
        actions allowed for the rest of the task), False (denied or timed out),
        or None when the user has no interactive channel — so the caller falls
        back to the unattended policy. The answer arrives out-of-band (e.g. a
        Telegram button), bypassing the agent lock, and resolves the future.

        *grantable* offers the "allow for this task" answer, on adapters that
        support it; *origin* names who is asking (a subagent, a background task).
        """
        reason = self._approval_unavailable_reason(user_id)
        if reason is not None:
            # Audit WHY no buttons were shown so a misconfiguration (e.g. the user
            # not being in TELEGRAM_TRUSTED_USERS) is diagnosable, then fall back.
            security.audit("approval_skip", f"{user_id} {tool_name}: {reason}")
            return None

        source = self._presence._users[str(user_id)].last_source
        adapter = self._adapters[source.platform]
        approval_id = f"{int(time.time())}-{next(self._approval_seq)}"
        fut: concurrent.futures.Future = concurrent.futures.Future()
        self._pending_approvals[approval_id] = fut

        grantable = grantable and getattr(adapter, "supports_grants", False)
        prompt = _approval_prompt(tool_name, tool_input, concern, origin, grantable)
        security.audit("approval_request", f"{user_id} {tool_name} {tool_input}")
        extra = {"grantable": True} if grantable else {}
        cf = asyncio.run_coroutine_threadsafe(
            adapter.request_approval(source, approval_id, prompt, **extra), self._loop
        )
        # If sending the prompt itself fails, surface it and deny immediately
        # rather than leaving the agent blocked until the timeout.
        cf.add_done_callback(lambda f: self._on_prompt_sent(approval_id, f))
        try:
            return fut.result(timeout=config.APPROVAL_TIMEOUT)
        except concurrent.futures.TimeoutError:
            security.audit("approval_timeout", f"{user_id} {tool_name}")
            asyncio.run_coroutine_threadsafe(
                adapter.expire_approval(source, approval_id), self._loop
            )
            return False
        finally:
            self._pending_approvals.pop(approval_id, None)

    def can_request_approval(self, user_id: str) -> bool:
        """Whether *user_id* could be shown an approval prompt right now. Auto
        mode only answers on behalf of a user who could have answered."""
        return self._approval_unavailable_reason(user_id) is None

    def _approval_unavailable_reason(self, user_id: str) -> str | None:
        """Why an interactive approval can't be sought, or None if it can."""
        if self._loop is None:
            return "gateway loop not running"
        presence = self._presence._users.get(str(user_id))
        if presence is None:
            return "user not reachable (no presence record)"
        adapter = self._adapters.get(presence.last_source.platform)
        if adapter is None or adapter.state != AdapterState.RUNNING:
            return f"adapter {presence.last_source.platform} unavailable"
        if not getattr(adapter, "supports_approvals", False):
            return f"adapter {presence.last_source.platform} has no approval UI"
        if not adapter.can_approve(user_id):
            return "user not trusted to approve (TELEGRAM_TRUSTED_USERS)"
        return None

    def _on_prompt_sent(self, approval_id: str, cf: concurrent.futures.Future) -> None:
        exc = cf.exception()
        if exc is not None:
            security.audit("approval_send_error", f"{approval_id}: {exc}")
            self.resolve_approval(approval_id, False)

    def resolve_approval(self, approval_id: str, approved: bool | str) -> bool:
        """Settle a pending approval with True, False or security.GRANT. Called
        on the gateway loop by an adapter when the user answers. Returns False
        if the id is unknown or already settled (e.g. it had timed out)."""
        fut = self._pending_approvals.get(approval_id)
        if fut is None or fut.done():
            return False
        fut.set_result(approved)
        return True

    async def start_all(self) -> None:
        self._loop = asyncio.get_running_loop()
        security.audit(
            "gateway_boot",
            f"data_dir={config.DATA_DIR} idle_check={config.IDLE_CHECK_INTERVAL}s "
            f"min_idle={config.MIN_IDLE_MINUTES}m max_msg={config.MAX_IDLE_MSG_SESSION} "
            f"quiet={config.QUIET_START}-{config.QUIET_END}",
        )
        for name, adapter in self._adapters.items():
            try:
                await adapter.start()
                security.audit("gateway_start", name)
            except Exception as exc:
                security.audit("gateway_start_error", f"{name}: {exc}")

        if config.IDLE_CHECK_INTERVAL > 0 and self._idle_task is None:
            self._idle_task = asyncio.create_task(self._idle_loop())
            security.audit("idle_loop_start", f"every {config.IDLE_CHECK_INTERVAL}s")
        elif config.IDLE_CHECK_INTERVAL <= 0:
            security.audit("idle_loop_disabled", "DP_IDLE_CHECK<=0")

    async def stop_all(self) -> None:
        from .. import tasks
        tasks.cancel_all()
        if self._idle_task is not None:
            self._idle_task.cancel()
            try:
                await self._idle_task
            except asyncio.CancelledError:
                pass
            self._idle_task = None

        for adapter in self._adapters.values():
            try:
                await adapter.stop()
            except Exception:
                pass

        # Usage still being priced (OpenRouter's generation data lags the
        # reply) must reach the billing service before the process exits.
        await asyncio.get_running_loop().run_in_executor(None, billing.flush, 30)

    async def _idle_loop(self) -> None:
        """Periodically reach out to users who have gone quiet. Idleness is
        tracked per user; each gets at most MAX_IDLE_MSG_SESSION unprompted
        messages until they speak again, and the model may decline (stay
        silent) on any given check."""
        min_idle_s = config.MIN_IDLE_MINUTES * 60
        while True:
            try:
                await asyncio.sleep(config.IDLE_CHECK_INTERVAL)
                await self._run_idle_pass(min_idle_s)
            except asyncio.CancelledError:
                raise
            except Exception as exc:               # never let the loop die
                security.audit("idle_loop_error", str(exc))

    async def _run_idle_pass(self, min_idle_s: float) -> None:
        if config.in_quiet_hours():
            security.audit("idle_skip", "quiet_hours")
            return                             # don't ping during quiet hours
        candidates = self._presence.idle_users(min_idle_s, config.MAX_IDLE_MSG_SESSION)
        security.audit(
            "idle_pass",
            f"tracked={len(self._presence._users)} candidates={len(candidates)} "
            f"min_idle={min_idle_s / 60:.0f}m cap={config.MAX_IDLE_MSG_SESSION}",
        )
        for p in candidates:
            idle_min = (time.time() - p.last_active) / 60
            adapter = self._adapters.get(p.last_source.platform)
            if not adapter or adapter.state != AdapterState.RUNNING:
                state = adapter.state.value if adapter else "missing"
                security.audit(
                    "idle_skip",
                    f"{p.user_id} adapter={p.last_source.platform}:{state}",
                )
                continue

            security.audit(
                "idle_check",
                f"{p.user_id} idle={idle_min:.1f}m nudges={p.nudges_sent} "
                f"reach={p.last_source.platform}:{p.last_source.chat_id}",
            )
            async with self._agent_lock:
                from .. import agent as _agent
                loop = asyncio.get_running_loop()
                user_id = p.user_id
                reply = await loop.run_in_executor(
                    None, lambda u=user_id: _agent.proactive_check(u)
                )

            if any(token in reply for token in SILENCE_TOKENS):
                security.audit("idle_silent", p.user_id)
                continue                           # model chose not to intrude

            try:
                await adapter.send(p.last_source, reply)
                adapter._on_success()
                self._presence.mark_nudged(p.user_id)
                security.audit("idle_nudge", p.user_id)
            except Exception as exc:
                security.audit("idle_send_error", str(exc))
                adapter._on_failure()

    def status(self) -> str:
        if not self._adapters:
            return "  (no adapters registered)"
        return "\n".join(f"  {n}: {a.state.value}" for n, a in self._adapters.items())
